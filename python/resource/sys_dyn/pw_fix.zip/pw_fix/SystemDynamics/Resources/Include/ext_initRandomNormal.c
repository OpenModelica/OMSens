#include <math.h>
#include <limits.h>

void ext_initRandomNormal()
{
    srand(time(NULL));
}
